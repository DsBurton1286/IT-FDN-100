#Create an application that uses a list to hold the following data:
'''
Id	Name	Email
1	Bob Smith	BSmith@Hotmail.com
2	Sue Jones	SueJ@Yahoo.com
3	Joe James	JoeJames@Gmail.com
'''
header = ['Id', 'Name', 'Email']
Id = [1, 2, 3]
Name = ['Bob Smith', 'Sue Jones', 'Joe James']
Email = ['BSmith@Hotmail.com', 'SueJ@Yahoo.com', 'JoeJames@Gmail.com']

tableData = [Id, Name, Email]

#Add code that lets users appends a new row of data.
while True:
    newUser = input('Would you like to add a user? (y/n) ')
    if newUser.lower() == 'y':
        # Add a loop that lets the user keep adding rows.
        Id.append(input('What is the users ID?: '))
        Name.append(input('What is the users first and last name?: '))
        Email.append(input('What is the users Email?: '))
        anotherUser = input('Would you like to add another user? (y/n)')
        if anotherUser.lower() == 'y':
            continue
        elif anotherUser.lower() == 'n':
            break
        else:
            print('please enter y or n.')
            continue
    elif newUser.lower() == 'n':
        break
    else:
        print('Please enter y or n.')
        continue

#Ask the user if they want to save the data to a file when they exit the loop.
writeData = input('Would you like to save the User to a file? (y/n)')
if writeData.lower() == 'y':
    # Save the data to a file if they say 'yes'
    userLi = open("C:\\users\\dsbur\\desktop\\HomeInventory.txt", "a")
    a = 0
    for i in header:
        userLi.write(str(i) + ', ')
    userLi.write('\n')
    while True:
        try:
            for x in tableData:
                userLi.write(str(x[a]) + ', ')
            userLi.write('\n')
            a = a + 1
        except IndexError:
            break
    userLi.close()




