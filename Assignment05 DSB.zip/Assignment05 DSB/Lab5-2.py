#Create an application that uses a dictionary to hold the following data:
'''
Id	Name	Email
1	Bob Smith	BSmith@Hotmail.com
2	Sue Jones	SueJ@Yahoo.com
3	Joe James	JoeJames@Gmail.com
'''
row1 = {'Id': 1, 'Name': 'Bob Smith', 'Email': 'BSmith@Hotmail.com'}
row2 = {'Id': 2, 'Name': 'Sue Jones', 'Email': 'SueJ@Yahoo.com'}
row3 = {'Id': 3, 'Name': 'Joe James', 'Email': 'JoeJames@Gmail.com'}

tableData = [row1, row2, row3]

#Add code that lets users appends a new row of data.
while True:
    newUser = input('Would you like to add a user? (y/n) ')
    if newUser.lower() == 'y':
        # Add a loop that lets the user keep adding rows.
        intId = int(input('What is the users ID?: '))
        strName = input('What is the users first and last name?: ')
        strEmail = input('What is the users Email?: ')
        dicNewRow = {'Id': intId, 'Name': strName, 'Email': strEmail}
        tableData.append(dicNewRow)
        continue
    elif newUser.lower() == 'n':
        break
    else:
        print('Please enter y or n.')
        continue

#Ask the user if they want to save the data to a file when they exit the loop.
writeData = input('Would you like to save the User to a file? (y/n)')
if writeData.lower() == 'y':
    # Save the data to a file if they say 'yes'
    userLi = open("C:\\users\\dsbur\\desktop\\HomeInventory.txt", "w+")
    while True:
        for x in tableData:
            keyWrite01 = (x['Id'])
            keyWrite02 = (x['Name'])
            keyWrite03 = (x['Email'])
            userLi.write(str(keyWrite01) + ', ')
            userLi.write(str.title(keyWrite02) + ', ')
            userLi.write(str.title(keyWrite03) + '\n')
        break
    userLi.close()
