#Divide you program into data, processing, and presentation sections.
#variables to store data
x = int(input('''Let's perform a math function, what 2 integers shall we use?\n
Value 1: '''))                  #User data to be used for function value1
y = int(input('value 2: '))     #User data to be used for function value2
v1 = None                       #Variable to store function value1
v2 = None                       #variable to store function value2
mathLst = []                    #List to store Sum, Difference, Product, Quotient

#Create a function that returns a list of the Sum,
#Difference, Product, and Quotient of two numbers.
#process information
def math(value1, value2):                   #Create function
    mathLst.append(value1 + value2,)        #Create an addition equation that appends to the list
    mathLst.append(value1 - value2,)        #Create an subtraction equation that appends to the list
    mathLst.append(value1 * value2,)        #Create an multiplication equation that appends to the list
    mathLst.append(value1 / value2,)        #Create an division equation that appends to the list
    return mathLst, value1, value2          #Return the values within the function

mathLst, v1, v2 = math(x, y)                #Store the functions data to the global variables

#Display the results to the user.
#Presentation
print('\n' + str(v1) + ' + ' + str(v2) + ' = ' + str(mathLst[0]))     #display the addition equation
print(str(v1) + ' - ' + str(v2) + ' = ' + str(mathLst[1]))            #display the subtraction equation
print(str(v1) + ' * ' + str(v2) + ' = ' + str(mathLst[2]))            #display the multiplication equation
print(str(v1) + ' / ' + str(v2) + ' = ' + str(mathLst[3]))            #display the division equation
