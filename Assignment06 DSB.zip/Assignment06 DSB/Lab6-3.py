#variables to store data
v1 = int(input('''Let's perform a math function using a class, what 2 integer shall we use?\n
Value1:'''))                           #User data to be used for function value1
v2 = int(input('Value2: '))            #User data to be used for function value2

#process information
#Create a class with (4) Methods, have them return a Sum,
#Difference, Product, and Quotient of two numbers.
#Name the class MathProcessor.
class MathProcessor(object):             #Create a class
#Name the methods AddValues, SubtractValues, MultiplyValues, DivideValues.

    @staticmethod
    def AddValues(value1, value2):          #Create an addition method
        addAnswer = value1 + value2         #create the addition equation
        return addAnswer                    #Return the answer within the method

    @staticmethod
    def SubValues(value1, value2):          #Create a subtraction method
        subAnswer = value1 - value2         #create the subtraction equation
        return subAnswer                    #Return the answer within the method

    @staticmethod
    def MulValues(value1, value2):          #Create a multiplication method
        mulAnswer = value1 * value2         #create the multiplication equation
        return mulAnswer                    #Return the answer within the method

    @staticmethod
    def DivValues(value1, value2):          #Create a division method
        divAnswer = value1 / value2         #create the division equation
        return divAnswer                    #Return the answer within the method

addAnswer = MathProcessor.AddValues(v1, v2)
subAnswer = MathProcessor.SubValues(v1, v2)
mulAnswer = MathProcessor.MulValues(v1, v2)
divAnswer = MathProcessor.DivValues(v1, v2)

#Presentation
#Display the results to the user by calling each method.
print('\n' + str(v1) + ' + ' + str(v2) + ' = ' + str(addAnswer))    #print the addition equation
print(str(v1) + ' - ' + str(v2) + ' = ' + str(subAnswer))           #print the addition equation
print(str(v1) + ' * ' + str(v2) + ' = ' + str(mulAnswer))           #print the addition equation
print(str(v1) + ' / ' + str(v2) + ' = ' + str(divAnswer))           #print the addition equation

