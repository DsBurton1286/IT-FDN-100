# -------------------------------------------------#
# Title: Working with Dictionaries, Classes and Methods
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog:
#   RRoot, 11/02/2016, Created starting template
#   DsBurton, 4/26/2018, Added code to complete assignment05
#   DsBurton, 5/5/2018, Altered Title and code to complete assignment06
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# -------------------------------

objFileName = 'C:\\users\\dsbur\\desktop\\ToDo.txt' #file destination to pull data from
dicRow = {} #empty dictionary to store information in
lstTable = [] #empty list to store my dictionary data creating a table


class ToDo(object):      #defines the class to store our methods

    @staticmethod
    def importData():  #defines the method to import the data from Todo.txt
        # Step 1 - Load data from a file
        # When the program starts, load each "row" of data
        # in "ToDo.txt" into a python Dictionary.
        # Add each dictionary "row" to a python list "table"
        with open(objFileName, 'r') as file:  # opens the file
            for text in file:  # loops through the items in the open file
                text = text.strip().split(',')  # strips the line breaks, and seperates the data at the comma
                dicRow = {'Task': text[0], 'Priority': text[1]}  # takes the data and adds to dictionary
                lstTable.append(dicRow)  # adds dictionary to a list creating the table.

    @staticmethod
    def main():      #defines the method to display a list of options to the user
        # Step 2
        # Display a menu of choices to the user
        print("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
        strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
        print()  # adding a new line
        # Step 3 -Show the current items in the table
        if (strChoice.strip() == '1'):
            ToDo.showData()
        # Step 4 - Add a new item to the list/Table
        elif (strChoice.strip() == '2'):
            ToDo.addTask()
        # Step 5 - Remove a new item to the list/Table
        elif (strChoice == '3'):
            ToDo.delTask()
        # Step 6 - Save tasks to the ToDo.txt file
        elif (strChoice == '4'):
            ToDo.saveData()
        elif (strChoice == '5'):
            # Step 7
            # Exit program
             pass # Exit the program

    @staticmethod
    def showData():      #defines the method to display the current data to the user
        # Step 3
        # Display all todo items to user
        a = 1 #gives the dictionary a number when working through the following loop
        for tasks in lstTable: #loops through the list to get the information
            print(a, ')    Task: ', tasks['Task'])
            print('   Priority: ', tasks['Priority'], '\n')
            a = a + 1 #increases the value by 1 for each loop giving every task a different number
        ToDo.main()

    @staticmethod
    def addTask():       #defines the method to add new tasks to the program
        # Step 4
        # Add a new item to the list/Table
        newTask = str.title(input('What is the name of the task?: ')) #gets the name of a new task
        newPrio = str.lower(input('What is the priority of this task?: ')) #gets the priority of the task
        DicRow = {'Task': newTask, 'Priority': newPrio} #creates new dictionary with users input
        lstTable.append(DicRow) #addpends list with new dictionary to add to the items in the list
        ToDo.main()

    @staticmethod
    def delTask():     #defines the method to delete tasks from the program
        # Step 5
        # Remove a new item to the list/Table
        while True: #starts another while loop to help with exception handling
            a = 1
            for tasks in lstTable: #same for loop as before to print tasks with a number
                print(a, ')    Task: ', tasks['Task'])
                print('   Priority: ', tasks['Priority'], '\n')
                a = a + 1
            try: #gets ready to handle an error if it occurs
                taskRem = int(input('Please select the task number to be removed: ')) #asks for what item to remove
                size = len(lstTable) #gets the length of how many items exist in the list
                if taskRem > size: #compares the users integer input to the quantity of items in the list
                    print('\n******Out of range******\n') #if users input was greater than the amount of items
                    continue
                else:
                    taskRem = taskRem - 1 #takes 1 away from user input (lists start at zero, my first item is 1)
                    del lstTable[taskRem] #deletes the the list item in the selected position
                    break
            except ValueError: #if user tries to input anything other than an INT
                print('\n****Each task has a number****\n')
                continue
        ToDo.main()

    @staticmethod
    def saveData():       #defines the method to save the updated data to the ToDo.txt file
        # Step 6
        # Save tasks to the ToDo.txt file
        fileSave = open(objFileName, 'w+') #opens file in write mode
        for lines in lstTable: #loops through lstTable
            keyWrite01 = (lines['Task']) #gets task from lstTable dictionaries
            keyWrite02 = (lines['Priority']) #gets priority from lstTable dictionaries
            fileSave.write(str.title(keyWrite01) + ',') #writes the task to file
            fileSave.write(str.lower(keyWrite02) + '\n') #writes the priority
        fileSave.close() #closes the file
        ToDo.main()

ToDo.importData()       #calls the method from the class to import the data from ToDo.txt
ToDo.main()             #calls the method from the class to display our men of options to the user.

